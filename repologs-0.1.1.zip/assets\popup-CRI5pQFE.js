import{a as e,n as t}from"./gemini-BRm8JvWe.js";import{r as n}from"./api-key-manager-2lnvrAC5.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();async function r(){let[i,a]=await Promise.all([n(),e()]),o=a.geminiModel||`gemini-2.5-flash`,s=a.deepMode,c=t.map(e=>`
    <label class="model-item">
      <input type="radio" name="gemini-model" value="${e.id}" ${o===e.id?`checked`:``}/>
      <span class="model-name">${e.name}</span>
      <span class="tag ${e.free?`tag-free`:`tag-pro`}">${e.free?`Free`:`Pro`}</span>
    </label>
  `).join(``),l=document.getElementById(`app`);l.innerHTML=`
    <div class="header">
      <span class="logo" style="display: flex; gap: 5px;"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex-shrink:0"><path d="m13 13.5 2-2.5-2-2.5"/><path d="m21 21-4.3-4.3"/><path d="M9 8.5 7 11l2 2.5"/><circle cx="11" cy="11" r="8"/></svg> RepoLogs</span>
      <span class="badge-free">Beta</span>
    </div>

    <div class="body">

      <div class="status-card">
        <div class="status-row">
          <span class="status-label">Free query</span>
          <span class="status-value ${i.systemKeyUsed?`used`:`ok`}">
            ${i.systemKeyUsed?`Used`:`Available`}
          </span>
        </div>
        <div class="status-row">
          <span class="status-label">Your API key</span>
          <span class="status-value ${i.hasUserKey?`ok`:``}">
            ${i.hasUserKey?`Configured`:`Not configured`}
          </span>
        </div>
        <div class="status-row">
          <span class="status-label">Total analyses</span>
          <span class="status-value">${i.analysisCount}</span>
        </div>
      </div>

      <div class="input-group">
        <p class="section-label">Your Gemini API key</p>
        <input
          type="password"
          id="api-key-input"
          placeholder="AIza..."
          value=""
          autocomplete="new-password"
        />
        <p class="input-hint">
          Get for free at
          <a href="https://aistudio.google.com" target="_blank">aistudio.google.com</a>
          → Get API key
        </p>
      </div>

      <button class="btn-primary" id="save-btn">Save API key</button>

      ${i.hasUserKey?`<button class="btn-danger" id="clear-btn">Remove API key</button>`:``}

      ${i.hasUserKey?`
        <div class="model-section">
          <p class="section-label">Gemini Model</p>
          <div class="model-list">${c}</div>
        </div>
      `:``}

      <div class="toggle-section">
        <div class="toggle-row">
          <div class="toggle-info">
            <span class="toggle-label">Deep analysis</span>
            <span class="toggle-desc">350 lines per file · Normal: 150 lines</span>
          </div>
          <label class="toggle-switch" aria-label="Toggle deep analysis">
            <input type="checkbox" id="deep-mode-toggle" ${s?`checked`:``} />
            <span class="toggle-thumb"></span>
          </label>
        </div>
      </div>

      <div id="msg"></div>

    </div>

    <div class="footer">
      Public repos · Free
    </div>
  `,document.getElementById(`save-btn`)?.addEventListener(`click`,async()=>{let e=document.getElementById(`api-key-input`).value.trim(),t=document.getElementById(`msg`);if(!e){t.innerHTML=`<p class="error-msg">Enter a valid API key</p>`;return}try{let n=await chrome.runtime.sendMessage({type:`SAVE_API_KEY`,key:e});n?.ok?(t.innerHTML=`<p class="success-msg">API key saved successfully!</p>`,setTimeout(r,1500)):t.innerHTML=`<p class="error-msg">Error: ${n?.error??`unknown`}</p>`}catch(e){t.innerHTML=`<p class="error-msg">Error: ${e.message}</p>`}}),document.getElementById(`clear-btn`)?.addEventListener(`click`,async()=>{await chrome.runtime.sendMessage({type:`CLEAR_API_KEY`}),r()}),document.querySelectorAll(`input[name="gemini-model"]`).forEach(e=>{e.addEventListener(`change`,()=>{e.checked&&chrome.runtime.sendMessage({type:`SAVE_GEMINI_MODEL`,model:e.value})})}),document.getElementById(`deep-mode-toggle`)?.addEventListener(`change`,e=>{let t=e.target.checked;chrome.runtime.sendMessage({type:`SAVE_DEEP_MODE`,deepMode:t})})}r();