var e={systemKeyUsed:!1,userApiKey:null,geminiModel:`gemini-2.5-flash`,deepMode:!1,analysisCount:0,cache:{},lastResults:{}};async function t(){let t=await chrome.storage.local.get(Object.keys(e));return{...e,...t}}async function n(e){await chrome.storage.local.set(e)}async function r(e,r){let i={...(await t()).cache,[e]:r},a=Object.keys(i);a.length>50&&delete i[a[0]],await n({cache:i})}async function i(e){return(await t()).lastResults[e]??null}async function a(e,r){await n({lastResults:{...(await t()).lastResults,[e]:r}})}function o(){return`You are an expert in code quality and software architecture.
Analyze the provided GitHub repository and return ONLY valid JSON, with no additional text,
no markdown, no code blocks. Just the raw JSON.

The JSON must follow exactly this structure:
{
  "reasoning": {
    "tests":           "<1-2 sentences justifying the tests score>",
    "security":        "<1-2 sentences justifying the security score>",
    "architecture":    "<1-2 sentences justifying the architecture score>",
    "codeQuality":     "<1-2 sentences justifying the codeQuality score>",
    "documentation":   "<1-2 sentences justifying the documentation score>",
    "consistency":     "<1-2 sentences justifying the consistency score>",
    "maintainability": "<1-2 sentences justifying the maintainability score>"
  },
  "dimensionScores": {
    "tests":           <integer 0-10>,
    "security":        <integer 0-10>,
    "architecture":    <integer 0-10>,
    "codeQuality":     <integer 0-10>,
    "documentation":   <integer 0-10>,
    "consistency":     <integer 0-10>,
    "maintainability": <integer 0-10>
  },
  "summary": "<2-3 sentence summary of the project>",
  "strengths": ["<strength 1>", "<strength 2>"],
  "weaknesses": ["<weakness 1>", "<weakness 2>"],
  "inconsistencies": ["<inconsistency 1>"],
  "architecture": {
    "rating": <"excellent" | "good" | "fair" | "poor">,
    "notes": "<observation about architecture>"
  },
  "recommendations": [
    { "priority": "high",   "text": "<urgent recommendation>" },
    { "priority": "medium", "text": "<important recommendation>" },
    { "priority": "low",    "text": "<optional improvement>" }
  ],
  "techStack": ["<technology 1>", "<technology 2>"],
  "securityFlags": ["<security flag if any>"]
}

════════════════════════════════════════════
SCORING METHODOLOGY (dimensionScores)
════════════════════════════════════════════

Each dimension is scored 0–10. Write the "reasoning" for each dimension BEFORE assigning
its score — this forces you to commit to concrete evidence before picking the number.

DIMENSIONS AND SCORING ANCHORS:

tests (weight 20%)
  0–2  No tests at all, or tests are entirely broken/empty
  3–4  Minimal tests, only smoke-level, incomplete coverage
  5–6  Partial tests — some critical paths covered, many gaps
  7–8  Good coverage of main flows, a few edge cases missing
  9–10 Comprehensive, well-organized, reliable tests with clear assertions

security (weight 20%)
  0–2  Exposed secrets, RCE/SQLi/XSS vulnerabilities, or no auth where required
  3–4  Serious risks: hardcoded credentials, unvalidated user input, insecure deps
  5–6  Moderate risks: some input validation missing, minor insecure practices
  7–8  Generally safe: no obvious vulnerabilities, minor improvements possible
  9–10 Strong security posture: validated input, no secrets, updated deps, defense-in-depth

architecture (weight 15%)
  0–2  No structure: all logic in one file/function, no separation of concerns
  3–4  Minimal structure: some separation but heavy coupling between layers
  5–6  Recognizable structure with clear issues: mixed responsibilities, some coupling
  7–8  Clear layers and responsibilities, minor coupling issues
  9–10 Excellent separation of concerns, cohesive modules, easy to extend

codeQuality (weight 15%)
  0–2  Unreadable: cryptic names, deeply nested logic, copy-paste everywhere
  3–4  Low quality: poor naming, complex functions, significant duplication
  5–6  Adequate: readable enough but with notable complexity or duplication
  7–8  Good: clear names, manageable functions, little duplication
  9–10 Excellent: idiomatic, self-documenting, DRY, low cyclomatic complexity

documentation (weight 10%)
  0–2  No README, no comments, no types/contracts anywhere
  3–4  Minimal README, missing setup instructions, no inline docs
  5–6  Basic README with setup, some comments, partial type coverage
  7–8  Clear README, good type coverage, strategic comments where needed
  9–10 Comprehensive docs: README, API docs, types, decision comments

consistency (weight 10%)
  0–2  No consistent style, patterns, or conventions across the codebase
  3–4  Inconsistent: mixed styles, naming conventions conflict, different patterns per file
  5–6  Mostly consistent with notable exceptions
  7–8  Consistent style and patterns, minor deviations
  9–10 Perfectly consistent: unified style, naming, and patterns throughout

maintainability (weight 10%)
  0–2  Unmaintainable: extreme tech debt, no way to change without breaking everything
  3–4  Hard to maintain: high debt, complex dependencies, no clear entry points
  5–6  Maintainable with effort: some debt, moderate complexity
  7–8  Easy to maintain: low debt, clear structure, manageable complexity
  9–10 Highly maintainable: minimal debt, clean design, straightforward to evolve

CALIBRATION RULES (mandatory):
  - A critical security flaw (hardcoded secrets, RCE, SQLi) → security ≤ 2
  - Complete absence of tests in a non-trivial project → tests ≤ 3
  - Do not penalize for features the project never intended to have
  - Empty/pure boilerplate project → cap all dimensions at 4
  - Be fair: a small personal project should not be judged as an enterprise system

════════════════════════════════════════════
EVALUATION CRITERIA
════════════════════════════════════════════
- Structure and organization (files, folders, separation of concerns)
- Code quality (readability, naming, patterns, complexity)
- Documentation (README, strategic comments, types/contracts)
- Tests (presence, apparent coverage, quality, reliability)
- Security (secrets, vulnerable dependencies, insecure practices)
- Consistency (style, patterns, conventions throughout the project)
- Architecture (layers, coupling, cohesion, scalability)
- Maintainability (duplication, technical debt, cyclomatic complexity)`}function s(e,t,n){let r=n.map(({path:e,content:t})=>`=== FILE: ${e} ===\n${t}\n=== END: ${e} ===`).join(`

`);return`Repository: ${e}/${t}
URL: https://github.com/${e}/${t}
Analyzed files: ${n.length}

${r}

Analyze this repository and return the JSON as instructed.`}var c=`https://generativelanguage.googleapis.com/v1beta/models`,l=`gemini-2.5-flash`,u=[{id:`gemini-2.5-flash`,name:`Gemini 2.5 Flash`,free:!0},{id:`gemini-2.5-flash-lite`,name:`Gemini 2.5 Flash Lite`,free:!0},{id:`gemini-2.5-pro`,name:`Gemini 2.5 Pro`,free:!1}],d=62e3,f=1;function p(e){return e>=85?`A`:e>=70?`B`:e>=55?`C`:e>=40?`D`:`F`}var m={tests:.2,security:.2,architecture:.15,codeQuality:.15,documentation:.1,consistency:.1,maintainability:.1};function h(e){let t=Object.keys(m).reduce((t,n)=>t+Math.max(0,Math.min(10,e[n]))*m[n],0);return Math.round(t*10)}function g(e){let t=e.replace(/^```json\s*/i,``).replace(/^```\s*/i,``).replace(/```\s*$/i,``).trim();try{let e=JSON.parse(t);if(!e.dimensionScores||typeof e.dimensionScores!=`object`)throw Error(`JSON missing dimensionScores field`);let n=h(e.dimensionScores);return e.score=n,e.grade=p(n),e}catch(e){throw Error(`Failed to parse Gemini response: ${e.message}`)}}async function _(e,t,n,r,i=l,a){let u=o(),p=s(t,n,r),m=JSON.stringify({system_instruction:{parts:[{text:u}]},contents:[{role:`user`,parts:[{text:p}]}],generationConfig:{temperature:0,maxOutputTokens:8192,responseMimeType:`application/json`}}),h=Math.ceil(m.length/3);console.log(`[Gemini] Model: ${i} | Estimated tokens: ~${h.toLocaleString()} | ${t}/${n} | ${r.length} file(s)`);async function _(t){let n=await fetch(`${c}/${i}:generateContent?key=${e}`,{method:`POST`,headers:{"Content-Type":`application/json`},body:m}),r;try{r=await n.json()}catch{throw Error(`Gemini HTTP ${n.status}: response is not valid JSON`)}if(r.error){console.error(`[Gemini] API error:`,JSON.stringify(r.error));let{code:e,message:n}=r.error;if(e===429){if(n.includes(`limit: 0`))throw Error(`Invalid model for selected API key or zero quota on project. Create your key at aistudio.google.com/app/apikey (not in Google Cloud Console).`);if(t>0){let e=Math.ceil(d/1e3);return console.warn(`[Gemini] Rate limit 429 — waiting ${e}s before retrying`),a?.(e),await new Promise(e=>setTimeout(e,d)),_(t-1)}throw Error(`Gemini rate limit reached. Please wait a few minutes and try again.`)}let i=n.toLowerCase().includes(`api key`)||n.toLowerCase().includes(`api_key`)||r.error.status===`INVALID_ARGUMENT`;throw e===400&&i?n.toLowerCase().includes(`expired`)?Error(`API key expired or still propagating. Wait 1-2 minutes after creating the key and try again.`):Error(`Invalid API key. Check in the extension settings.`):Error(`Gemini API [${e}]: ${n}`)}if(!n.ok)throw Error(`Gemini HTTP ${n.status}: ${n.statusText}`);if(!r.candidates?.[0]?.content?.parts?.[0]?.text)throw Error(`Empty response from Gemini`);let o=r.candidates[0].content.parts[0].text;return g(o)}return _(f)}export{t as a,n as c,i,u as n,r as o,_ as r,a as s,l as t};