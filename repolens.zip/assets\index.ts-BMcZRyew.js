import{i as e,n as t}from"./gemini-Dh4Er9PI.js";var n=`repolens-analyze-btn`,r=`repolens-eye-btn`,i=`repolens-wrapper`,a=`repolens-injected`,o=`repolens-btn-styles`;function s(){if(document.getElementById(o))return;let e=document.createElement(`style`);e.id=o,e.textContent=`
    #${n} {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 5px 14px;
      font-size: 13px;
      font-weight: 500;
      line-height: 20px;
      letter-spacing: 0.02em;
      color: var(--color-btn-text, #c9d1d9);
      background: var(--color-btn-bg, #11141d);
      border: 0.5px solid var(--color-btn-border, rgba(224, 240, 255, 0.66));
      border-radius: 6px;
      cursor: pointer;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Noto Sans', sans-serif;
      white-space: nowrap;
      position: relative;
      z-index: 0;
      overflow: visible;
      transition: background 0.2s ease, color 0.2s ease, border-color 0.2s ease;
    }
    [data-color-mode="light"] #${n},
    [data-color-mode="auto"] #${n} {
      color: var(--color-btn-text, #24292f);
      background: var(--color-btn-bg, #f6f8fa);
      border: 0.5px solid var(--color-btn-border, #d0d7de);
    }
    @media (prefers-color-scheme: dark) {
      [data-color-mode="auto"] #${n} {
        color: var(--color-btn-text, #c9d1d9);
        background: var(--color-btn-bg, #11141d);
        border: 0.5px solid var(--color-btn-border, rgba(224, 240, 255, 0.66));
      }
    }

    #${n}::before,
    #${n}::after {
      content: '';
      position: absolute;
      left: -2px;
      top: -2px;
      border-radius: 8px;
      background: linear-gradient(45deg,
        #0d1117, #0d1117, #13171d,
        #343d47af, #13171d,
        #13171d, #0d1117, #0d1117
      );
      background-size: 400%;
      width: calc(100% + 4px);
      height: calc(100% + 4px);
      z-index: -1;
      animation: repolens-steam 30s linear infinite;
    }
    #${n}::after {
      filter: blur(8px);
    }
    [data-color-mode="light"] #${n}::before,
    [data-color-mode="light"] #${n}::after {
      background: linear-gradient(45deg,
        #f6f8fa, #ffffff, #eaeef2,
        #c8d0daaf, #eaeef2,
        #eaeef2, #f6f8fa, #f6f8fa
      );
      background-size: 400%;
    }
    @media (prefers-color-scheme: light) {
      [data-color-mode="auto"] #${n}::before,
      [data-color-mode="auto"] #${n}::after {
        background: linear-gradient(45deg,
          #f6f8fa, #ffffff, #eaeef2,
          #c8d0daaf, #eaeef2,
          #eaeef2, #f6f8fa, #f6f8fa
        );
        background-size: 400%;
      }
    }

    @keyframes repolens-steam {
      0%   { background-position: 0 0; }
      50%  { background-position: 400% 0; }
      100% { background-position: 0 0; }
    }
    #${n}:hover:not(:disabled) {
      background: var(--color-btn-hover-bg, #30363d);
      color: var(--color-fg-default, #e6edf3);
      border: 0.5px solid var(--color-btn-border, #a4b3c7);
    }
    [data-color-mode="light"] #${n}:hover:not(:disabled),
    [data-color-mode="auto"] #${n}:hover:not(:disabled) {
      background: var(--color-btn-hover-bg, #e8eaed);
      color: var(--color-fg-default, #24292f);
      border: 0.5px solid var(--color-btn-border, #b0bac4);
    }
    @media (prefers-color-scheme: dark) {
      [data-color-mode="auto"] #${n}:hover:not(:disabled) {
        background: var(--color-btn-hover-bg, #30363d);
        color: var(--color-fg-default, #e6edf3);
        border: 0.5px solid var(--color-btn-border, #a4b3c7);
      }
    }

    #${n}:active:not(:disabled) {
      transform: translateY(1px);
    }
    #${n}:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    #${r} {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 30px;
      height: 30px;
      padding: 0;
      margin-left: 6px;
      color: var(--color-btn-text, #c9d1d9c4);
      background: var(--color-btn-bg, #0d1117);
      border: 0.5px solid var(--color-btn-border, rgba(224, 240, 255, 0.23));
      border-radius: 6px;
      cursor: pointer;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.2s ease, background 0.2s ease, color 0.2s ease;
    }
    [data-color-mode="light"] #${r},
    [data-color-mode="auto"] #${r} {
      color: var(--color-btn-text, #57606a);
      background: var(--color-btn-bg, #f6f8fa);
      border: 0.5px solid var(--color-btn-border, #d0d7de);
    }
    @media (prefers-color-scheme: dark) {
      [data-color-mode="auto"] #${r} {
        color: var(--color-btn-text, #c9d1d9c4);
        background: var(--color-btn-bg, #0d1117);
        border: 0.5px solid var(--color-btn-border, rgba(224, 240, 255, 0.23));
      }
    }
    #${r}.visible {
      opacity: 1;
      pointer-events: auto;
    }
    #${r}:hover {
      background: var(--color-btn-hover-bg, #30363d);
      color: var(--color-fg-default, #e6edf3);
    }
    [data-color-mode="light"] #${r}:hover,
    [data-color-mode="auto"] #${r}:hover {
      background: var(--color-btn-hover-bg, #e8eaed);
      color: var(--color-fg-default, #24292f);
    }
    @media (prefers-color-scheme: dark) {
      [data-color-mode="auto"] #${r}:hover {
        background: var(--color-btn-hover-bg, #30363d);
        color: var(--color-fg-default, #e6edf3);
      }
    }
    #${r}:active {
      transform: translateY(1px);
    }
  `,document.head.appendChild(e)}function c(){let e=location.pathname.match(/^\/([^/]+)\/([^/]+)/);if(!e)return null;let t=location.pathname.split(`/`).filter(Boolean);return t.length<2||[`settings`,`marketplace`,`explore`,`notifications`].includes(t[0])?null:{owner:e[1],repo:e[2]}}function l(){return document.querySelector(`.OverviewContent-module__Box_6__Y_Yb_`)??document.querySelector(`.OverviewContent-module__Box_2__Di8Pb`)??document.querySelector(`BorderGrid-row`)??null}function u(e){if(document.getElementById(n))return;let t=c();if(!t)return;let r=l();if(!r)return;s();let o=document.createElement(`div`);o.id=i,o.style.cssText=`display: inline-flex; align-items: center; padding: 0 16px;`;let u=document.createElement(`button`);u.id=n,u.setAttribute(`data-repolens`,a),u.innerHTML=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex-shrink:0"><path d="m13 13.5 2-2.5-2-2.5"/><path d="m21 21-4.3-4.3"/><path d="M9 8.5 7 11l2 2.5"/><circle cx="11" cy="11" r="8"/></svg><span>RepoLens</span>`,u.addEventListener(`click`,()=>{e(t.owner,t.repo)}),o.appendChild(u),r.insertBefore(o,r.firstChild)}function d(e){let t=document.getElementById(i);if(!t)return;let n=document.getElementById(r);if(n){n.onclick=e;return}n=document.createElement(`button`),n.id=r,n.title=`Ver última análise`,n.setAttribute(`aria-label`,`Ver última análise`),n.innerHTML=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`,n.onclick=e,t.appendChild(n)}function f(){document.getElementById(r)?.classList.add(`visible`)}function p(e){let t=document.getElementById(n);if(!t)return;t.disabled=e;let r=t.querySelector(`span`);r&&(r.textContent=e?`Analisando...`:`RepoLens`)}var m=`repolens-modal-host`,h=+(2*Math.PI*40).toFixed(2);function g(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function _(){let e=document.documentElement.getAttribute(`data-color-mode`);return e===`dark`?!0:e===`light`?!1:window.matchMedia?.(`(prefers-color-scheme: dark)`).matches??!1}function v(e){return e>=85?`#1a7f37`:e>=70?`#0969da`:e>=55?`#9a6700`:e>=40?`#bc4c00`:`#cf222e`}var y={A:{color:`#1a7f37`,bg:`#dafbe1`,label:`Excelente`},B:{color:`#0969da`,bg:`#ddf4ff`,label:`Bom`},C:{color:`#9a6700`,bg:`#fff8c5`,label:`Regular`},D:{color:`#bc4c00`,bg:`#fff1e5`,label:`Ruim`},F:{color:`#cf222e`,bg:`#ffebe9`,label:`Crítico`}};function b(e){return y[e]??{color:`#636c76`,bg:`#f6f8fa`,label:`-`}}var x={excellent:`Excelente`,good:`Boa`,fair:`Regular`,poor:`Fraca`},S={high:`Alta`,medium:`Média`,low:`Baixa`},C={high:`rl-badge--red`,medium:`rl-badge--amber`,low:`rl-badge--green`};function w(e,t){return`
    <svg viewBox="0 0 100 100" width="88" height="88" class="rl-ring" aria-hidden="true">
      <circle class="rl-ring-track" cx="50" cy="50" r="40"/>
      <circle class="rl-ring-fill" cx="50" cy="50" r="40"
        stroke="${t}"
        stroke-dasharray="${h}"
        style="--rl-circ:${h};--rl-target:${+(h*(1-e/100)).toFixed(2)}"/>
    </svg>`}function T(){return`
    :host { all: initial; }
    * { box-sizing: border-box; }

    /* ── Theme tokens (on overlay, inherited by all children) ── */
    .rl-ov {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
      --bg:        #ffffff;
      --bg-sub:    #f6f8fa;
      --bg-in:     #eaeef2;
      --bdr:       #d0d7de;
      --sh:        0 8px 24px rgba(140,149,159,.2), 0 2px 6px rgba(140,149,159,.12);
      --tx:        #1f2328;
      --tx-m:      #636c76;
      --green:     #1a7f37; --green-bg: #dafbe1;
      --amber:     #9a6700; --amber-bg: #fff8c5;
      --red:       #cf222e; --red-bg:   #ffebe9;
      --blue:      #0969da; --blue-bg:  #ddf4ff;
      --purple:    #8250df; --purple-bg:#fbefff;
      --r:         12px;
    }
    .rl-ov.dk {
      --bg:        #161b22;
      --bg-sub:    #0d1117;
      --bg-in:     #21262d;
      --bdr:       #30363d;
      --sh:        0 8px 32px rgba(0,0,0,.55), 0 2px 8px rgba(0,0,0,.3);
      --tx:        #e6edf3;
      --tx-m:      #8b949e;
      --green:     #3fb950; --green-bg: rgba(63,185,80,.13);
      --amber:     #d29922; --amber-bg: rgba(210,153,34,.13);
      --red:       #f85149; --red-bg:   rgba(248,81,73,.13);
      --blue:      #58a6ff; --blue-bg:  rgba(88,166,255,.13);
      --purple:    #bc8cff; --purple-bg:rgba(188,140,255,.13);
    }

    /* ── Overlay backdrop ── */
    .rl-ov {
      position: fixed; inset: 0; z-index: 999999;
      background: rgba(1,4,9,.65);
      backdrop-filter: blur(3px) saturate(120%);
      display: flex; align-items: center; justify-content: center;
      padding: 16px;
      animation: rl-fade .18s ease;
    }
    @keyframes rl-fade { from { opacity:0 } to { opacity:1 } }

    /* ── Result modal ── */
    .rl-modal {
      background: var(--bg); border: 1px solid var(--bdr);
      border-radius: var(--r); box-shadow: var(--sh);
      width: 100%; max-width: 680px; max-height: 88vh;
      display: flex; flex-direction: column; overflow: hidden;
      animation: rl-up .24s cubic-bezier(.16,1,.3,1);
    }
    @keyframes rl-up {
      from { transform: translateY(22px); opacity:0 }
      to   { transform: translateY(0);    opacity:1 }
    }

    /* Header */
    .rl-hd {
      display: flex; justify-content: space-between; align-items: center;
      padding: 12px 20px; border-bottom: 1px solid var(--bdr);
      background: var(--bg-sub); flex-shrink: 0;
    }
    .rl-brand { display: flex; align-items: center; gap: 8px; }
    .rl-bname { font-size: 14px; font-weight: 600; color: var(--tx); letter-spacing: -.2px; }
    .rl-pw {
      font-size: 10px; font-weight: 500; padding: 2px 7px; border-radius: 99px;
      background: var(--purple-bg); color: var(--purple);
      border: 1px solid currentColor; opacity: .8;
    }
    .rl-hactions { display: flex; align-items: center; gap: 6px; }
    .rl-xbtn {
      display: flex; align-items: center; justify-content: center;
      width: 26px; height: 26px; padding: 0;
      border: 1px solid var(--bdr); border-radius: 6px;
      background: var(--bg); color: var(--tx-m); cursor: pointer;
      transition: background .1s, color .1s;
    }
    .rl-xbtn:hover { background: var(--bg-in); color: var(--tx); }

    /* Scrollable body */
    .rl-bd { overflow-y: auto; flex: 1; padding: 20px; display: flex; flex-direction: column; gap: 16px; }

    /* ── Hero: ring + grade + summary ── */
    .rl-hero { display: flex; align-items: center; gap: 20px; }

    .rl-rw { position: relative; width: 88px; height: 88px; flex-shrink: 0; }
    .rl-ring { display: block; }
    .rl-ring-track { fill: none; stroke: var(--bg-in); stroke-width: 8; }
    .rl-ring-fill {
      fill: none; stroke-width: 8; stroke-linecap: round;
      transform-origin: 50% 50%; transform: rotate(-90deg);
      animation: rl-ring .9s .1s cubic-bezier(.16,1,.3,1) both;
    }
    @keyframes rl-ring {
      from { stroke-dashoffset: var(--rl-circ) }
      to   { stroke-dashoffset: var(--rl-target) }
    }
    .rl-rov {
      position: absolute; inset: 0;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
    }
    .rl-snum { font-size: 22px; font-weight: 700; color: var(--tx); line-height: 1; }
    .rl-ssub { font-size: 10px; color: var(--tx-m); }

    .rl-hi { flex: 1; min-width: 0; }
    .rl-grow { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
    .rl-gbadge {
      display: inline-flex; align-items: center;
      font-size: 12px; font-weight: 600; padding: 3px 10px;
      border-radius: 99px; border: 1px solid transparent;
    }
    .rl-sum { font-size: 13px; color: var(--tx); line-height: 1.6; margin: 0 0 10px; }
    .rl-chips { display: flex; flex-wrap: wrap; gap: 5px; }
    .rl-chip {
      font-size: 11px; padding: 2px 8px; border-radius: 99px;
      background: var(--bg-sub); color: var(--tx-m); border: 1px solid var(--bdr);
    }

    /* Architecture card */
    .rl-arch {
      display: flex; align-items: flex-start; gap: 12px;
      padding: 12px 14px; border-radius: 8px;
      background: var(--bg-sub); border: 1px solid var(--bdr);
    }
    .rl-aico { font-size: 18px; line-height: 1.4; flex-shrink: 0; }
    .rl-ameta { display: flex; align-items: center; gap: 6px; margin-bottom: 3px; }
    .rl-albl { font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: var(--tx-m); font-weight: 500; }
    .rl-arat { font-size: 12px; font-weight: 600; color: var(--tx); }
    .rl-anotes { font-size: 12px; color: var(--tx-m); line-height: 1.55; margin: 0; }

    /* 2-col grid */
    .rl-g2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    @media (max-width: 480px) { .rl-g2 { grid-template-columns: 1fr; } }

    /* Section */
    .rl-sec { display: flex; flex-direction: column; gap: 7px; }
    .rl-ttl {
      font-size: 11px; font-weight: 600; margin: 0; letter-spacing: .05em;
      text-transform: uppercase; padding-bottom: 6px;
      border-bottom: 1px solid; display: flex; align-items: center; gap: 5px;
    }
    .rl-ttl--green { color: var(--green); border-color: var(--green-bg); }
    .rl-ttl--amber { color: var(--amber); border-color: var(--amber-bg); }
    .rl-ttl--red   { color: var(--red);   border-color: var(--red-bg);   }
    .rl-ttl--blue  { color: var(--blue);  border-color: var(--blue-bg);  }

    /* List */
    .rl-ul { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 4px; }
    .rl-li {
      display: flex; align-items: flex-start; gap: 8px;
      font-size: 12px; line-height: 1.5; padding: 6px 10px; border-radius: 6px; color: var(--tx);
    }
    .rl-li--green { background: var(--green-bg); }
    .rl-li--amber { background: var(--amber-bg); }
    .rl-li--red   { background: var(--red-bg); }
    .rl-li--muted { background: var(--bg-sub); color: var(--tx-m); }
    .rl-dot { width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; margin-top: 4px; }
    .rl-li--green .rl-dot { background: var(--green); }
    .rl-li--amber .rl-dot { background: var(--amber); }
    .rl-li--red   .rl-dot { background: var(--red); }
    .rl-li--muted .rl-dot { background: var(--tx-m); }

    /* Recommendations */
    .rl-recs { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px; }
    .rl-rec { display: flex; align-items: flex-start; gap: 8px; color: var(--tx); }
    .rl-rtx { font-size: 12px; line-height: 1.55; flex: 1; }
    .rl-badge {
      display: inline-flex; align-items: center; flex-shrink: 0;
      font-size: 10px; font-weight: 600; padding: 1px 6px;
      border-radius: 99px; border: 1px solid; white-space: nowrap; margin-top: 2px;
    }
    .rl-badge--red   { background: var(--red-bg);   color: var(--red);   border-color: var(--red);   }
    .rl-badge--amber { background: var(--amber-bg); color: var(--amber); border-color: var(--amber); }
    .rl-badge--green { background: var(--green-bg); color: var(--green); border-color: var(--green); }

    /* Footer */
    .rl-ft {
      font-size: 11px; color: var(--tx-m); text-align: center;
      padding: 10px 20px; border-top: 1px solid var(--bdr);
      background: var(--bg-sub); flex-shrink: 0;
    }

    /* ── Loading card ── */
    .rl-lc {
      background: var(--bg); border: 1px solid var(--bdr);
      border-radius: var(--r); box-shadow: var(--sh);
      padding: 40px 48px; text-align: center;
      min-width: 280px; max-width: 380px;
      position: relative;
      animation: rl-up .22s cubic-bezier(.16,1,.3,1);
    }
    .rl-spin {
      width: 40px; height: 40px; margin: 0 auto 20px;
      border: 3px solid var(--bg-in); border-top-color: var(--purple);
      border-radius: 50%; animation: rl-s .65s linear infinite;
    }
    @keyframes rl-s { to { transform: rotate(360deg) } }
    .rl-step { font-size: 13px; font-weight: 500; color: var(--tx); margin: 0 0 14px; }
    .rl-bar { height: 3px; background: var(--bg-in); border-radius: 99px; overflow: hidden; margin-bottom: 6px; }
    .rl-fill {
      height: 100%; background: linear-gradient(90deg, var(--purple) 0%, #bc8cff 100%);
      border-radius: 99px; transition: width .4s ease;
    }
    .rl-pct { font-size: 11px; color: var(--tx-m); margin: 0 0 16px; }

    /* ── Error card ── */
    .rl-ec {
      background: var(--bg); border: 1px solid var(--bdr);
      border-radius: var(--r); box-shadow: var(--sh);
      padding: 36px 40px; text-align: center;
      max-width: 400px; min-width: 280px;
      position: relative;
      animation: rl-up .22s cubic-bezier(.16,1,.3,1);
    }
    .rl-xbtn--corner {
      position: absolute; top: 10px; right: 10px;
    }
    .rl-eico { font-size: 36px; margin-bottom: 12px; }
    .rl-ettl { font-size: 16px; font-weight: 600; color: var(--tx); margin: 0 0 8px; }
    .rl-emsg { font-size: 13px; color: var(--tx-m); line-height: 1.55; margin: 0 0 14px; }
    .rl-ehint { font-size: 12px; color: var(--tx-m); line-height: 1.55; margin: 0 0 16px; }
    .rl-ehint a { color: var(--blue); }

    /* ── Shared button styles ── */
    .rl-btn {
      display: inline-flex; align-items: center; justify-content: center;
      padding: 6px 16px; font-size: 13px; font-weight: 500;
      border-radius: 6px; cursor: pointer; border: 1px solid; transition: opacity .12s;
    }
    .rl-btn--primary { background: var(--purple); color: #fff; border-color: var(--purple); }
    .rl-btn--primary:hover { opacity: .87; }
    .rl-btn--secondary { background: var(--bg); color: var(--tx); border-color: var(--bdr); }
    .rl-btn--secondary:hover { background: var(--bg-sub); }
    .rl-btn:disabled { opacity: .5; cursor: default; }

    /* ── API key form (shared across loading/result/error/key-form) ── */
    .rl-keyrow {
      display: flex; gap: 6px; width: 100%; margin-bottom: 8px;
    }
    .rl-keyinput {
      flex: 1; padding: 6px 10px; font-size: 13px; font-family: monospace;
      border: 1px solid var(--bdr); border-radius: 6px;
      background: var(--bg-sub); color: var(--tx); outline: none;
    }
    .rl-keyinput:focus { border-color: var(--purple); box-shadow: 0 0 0 2px rgba(130,80,223,.2); }
    .rl-keymsg { font-size: 12px; margin: 0; min-height: 16px; }
    .rl-keymsg--ok  { color: var(--green); }
    .rl-keymsg--err { color: var(--red); }

    /* subtle text link for "Configurar API key" in loading/error cards */
    .rl-keylnk {
      display: inline-flex; align-items: center; gap: 4px;
      background: none; border: none; cursor: pointer;
      font-size: 11px; color: var(--tx-m); padding: 4px 8px;
      border-radius: 6px; transition: background .1s, color .1s;
      margin-top: 8px;
    }
    .rl-keylnk:hover { background: var(--bg-sub); color: var(--purple); }

    /* ── Model selector ── */
    .rl-model-section { width: 100%; margin-top: 14px; text-align: left; }
    .rl-model-lbl {
      font-size: 11px; font-weight: 600; color: var(--tx-m);
      text-transform: uppercase; letter-spacing: .05em; margin-bottom: 6px;
    }
    .rl-model-list {
      max-height: 152px; overflow-y: auto;
      border: 1px solid var(--bdr); border-radius: 8px;
      background: var(--bg-sub);
    }
    .rl-model-item {
      display: flex; align-items: center; gap: 8px;
      padding: 7px 10px; cursor: pointer;
      border-bottom: 1px solid var(--bdr); transition: background .1s;
    }
    .rl-model-item:last-child { border-bottom: none; }
    .rl-model-item:hover { background: var(--bg-in); }
    .rl-model-item input[type="radio"] { accent-color: var(--purple); flex-shrink: 0; cursor: pointer; }
    .rl-model-name { font-size: 12px; color: var(--tx); flex: 1; }
    .rl-tag {
      font-size: 10px; font-weight: 600; padding: 1px 6px;
      border-radius: 99px; border: 1px solid; flex-shrink: 0;
    }
    .rl-tag--free { background: var(--green-bg); color: var(--green); border-color: var(--green); }
    .rl-tag--pro  { background: var(--amber-bg); color: var(--amber); border-color: var(--amber); }

    /* ── Deep mode toggle ── */
    .rl-toggle-row {
      display: flex; align-items: center; justify-content: space-between; gap: 12px;
      width: 100%; margin-top: 14px; padding: 10px 12px;
      background: var(--bg-sub); border: 1px solid var(--bdr); border-radius: 8px;
      text-align: left;
    }
    .rl-toggle-info { display: flex; flex-direction: column; gap: 2px; }
    .rl-toggle-lbl { font-size: 13px; font-weight: 500; color: var(--tx); }
    .rl-toggle-desc { font-size: 11px; color: var(--tx-m); }
    .rl-toggle-sw {
      position: relative; width: 32px; height: 18px; flex-shrink: 0; cursor: pointer;
    }
    .rl-toggle-sw input { opacity: 0; width: 0; height: 0; position: absolute; }
    .rl-toggle-thumb {
      position: absolute; inset: 0; background: var(--bdr); border-radius: 99px;
      transition: background 0.2s ease;
    }
    .rl-toggle-thumb::before {
      content: ''; position: absolute;
      width: 12px; height: 12px; left: 3px; top: 3px;
      background: #fff; border-radius: 50%; transition: transform 0.2s ease;
    }
    .rl-toggle-sw input:checked + .rl-toggle-thumb { background: var(--purple); }
    .rl-toggle-sw input:checked + .rl-toggle-thumb::before { transform: translateX(14px); }
  `}function E(e,t,n){return`<div class="rl-ov${t?` dk`:``}"${n?` id="${n}"`:``}>${e}</div>`}function D(){return`<svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.749.749 0 011.275.326.749.749 0 01-.215.734L9.06 8l3.22 3.22a.749.749 0 01-.326 1.275.749.749 0 01-.734-.215L8 9.06l-3.22 3.22a.751.751 0 01-1.042-.018.751.751 0 01-.018-1.042L6.94 8 3.72 4.78a.75.75 0 010-1.06z"/></svg>`}function O(){return`<svg viewBox="0 0 16 16" width="12" height="12" fill="currentColor" aria-hidden="true"><path d="M6.5 0a6.5 6.5 0 0 1 5.25 10.325l3.849 3.851a.75.75 0 0 1-1.06 1.06l-3.851-3.849A6.5 6.5 0 1 1 6.5 0zm0 1.5a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0 2a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm0 1.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z"/></svg>`}function k(){return`
    <div class="rl-keyrow">
      <input class="rl-keyinput" id="rl-key-input" type="password" placeholder="AIza..." autocomplete="new-password"/>
      <button class="rl-btn rl-btn--primary" id="rl-save-key">Salvar</button>
    </div>
    <p class="rl-keymsg" id="rl-key-msg"></p>
  `}function A(){return`
    <label class="rl-toggle-row" id="rl-deep-toggle-row">
      <div class="rl-toggle-info">
        <span class="rl-toggle-lbl">Análise profunda</span>
        <span class="rl-toggle-desc">350 linhas por arquivo · Normal: 150 linhas</span>
      </div>
      <span class="rl-toggle-sw" aria-label="Alternar análise profunda">
        <input type="checkbox" id="rl-deep-mode"/>
        <span class="rl-toggle-thumb"></span>
      </span>
    </label>
  `}function j(){return`
    <div class="rl-model-section" id="rl-model-section" style="display:none">
      <p class="rl-model-lbl">Modelo Gemini</p>
      <div class="rl-model-list">${t.map(e=>`
    <label class="rl-model-item">
      <input type="radio" name="rl-gemini-model" value="${e.id}"/>
      <span class="rl-model-name">${g(e.name)}</span>
      <span class="rl-tag ${e.free?`rl-tag--free`:`rl-tag--pro`}">${e.free?`Grátis`:`Pro`}</span>
    </label>
  `).join(``)}</div>
    </div>
  `}function M(e,t,n){return E(`
    <div class="rl-lc">
      <button class="rl-xbtn rl-xbtn--corner" id="rl-close" aria-label="Fechar">${D()}</button>
      <div class="rl-spin"></div>
      <p class="rl-step">${g(e)}</p>
      <div class="rl-bar"><div class="rl-fill" style="width:${t}%"></div></div>
      <p class="rl-pct">${t}%</p>
      
    </div>
  `,n)}function N(e,t,n){let r=t?`<p class="rl-ehint">
        Obtenha sua key gratuita em
        <a href="https://aistudio.google.com" target="_blank">aistudio.google.com</a>
        → <strong>Get API key</strong>
      </p>
      ${k()}`:`<button class="rl-btn rl-btn--secondary" id="rl-close-btn">Fechar</button>
       <button class="rl-keylnk" id="rl-key-btn">${O()} Configurar API key</button>`;return E(`
    <div class="rl-ec">
      <button class="rl-xbtn rl-xbtn--corner" id="rl-close" aria-label="Fechar">${D()}</button>
      <div class="rl-eico">${t?`🔑`:`⚠️`}</div>
      <h3 class="rl-ettl">${t?`API key necessária`:`Erro na análise`}</h3>
      <p class="rl-emsg">${g(e)}</p>
      ${r}
    </div>
  `,n)}function P(e){return E(`
    <div class="rl-ec">
      <button class="rl-xbtn rl-xbtn--corner" id="rl-close" aria-label="Fechar">${D()}</button>
      <div class="rl-eico">🔑</div>
      <h3 class="rl-ettl">Configurar API key</h3>
      <p class="rl-emsg">Cole sua Gemini API key abaixo.</p>
      <p class="rl-ehint">
        Obtenha gratuitamente em
        <a href="https://aistudio.google.com" target="_blank">aistudio.google.com</a>
        → <strong>Get API key</strong>
      </p>
      ${k()}
      ${j()}
      ${A()}
      <button class="rl-keylnk" id="rl-cancel">Cancelar</button>
    </div>
  `,e)}function F(e,t,n){let r=b(e.grade),i=v(e.score),a=(e,t)=>`<li class="rl-li ${t}"><span class="rl-dot"></span><span>${g(e)}</span></li>`,o=e.strengths.map(e=>a(e,`rl-li--green`)).join(``),s=e.weaknesses.map(e=>a(e,`rl-li--amber`)).join(``),c=e.inconsistencies.length?e.inconsistencies.map(e=>a(e,`rl-li--red`)).join(``):a(`Nenhuma inconsistência detectada`,`rl-li--muted`),l=e.techStack.map(e=>`<span class="rl-chip">${g(e)}</span>`).join(``),u=e.recommendations.map(e=>`
    <li class="rl-rec">
      <span class="rl-badge ${C[e.priority]??`rl-badge--green`}">${S[e.priority]??e.priority}</span>
      <span class="rl-rtx">${g(e.text)}</span>
    </li>
  `).join(``),d=e.securityFlags.length?`
    <section class="rl-sec">
      <h3 class="rl-ttl rl-ttl--red">⚑ Flags de segurança</h3>
      <ul class="rl-ul">${e.securityFlags.map(e=>a(e,`rl-li--red`)).join(``)}</ul>
    </section>
  `:``;return E(`
    <div class="rl-modal">

      <header class="rl-hd">
        <div class="rl-brand">
          <span class="rl-bname">RepoLens</span>
          <span class="rl-pw">${g(n)}</span>
        </div>
        <div class="rl-hactions">
          <button class="rl-xbtn" id="rl-key-btn" aria-label="Configurar API key" title="Configurar API key">
            ${O()}
          </button>
          <button class="rl-xbtn" id="rl-close" aria-label="Fechar">
            <svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor">
              <path d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.749.749 0 011.275.326.749.749 0 01-.215.734L9.06 8l3.22 3.22a.749.749 0 01-.326 1.275.749.749 0 01-.734-.215L8 9.06l-3.22 3.22a.751.751 0 01-1.042-.018.751.751 0 01-.018-1.042L6.94 8 3.72 4.78a.75.75 0 010-1.06z"/>
            </svg>
          </button>
        </div>
      </header>

      <div class="rl-bd">

        <div class="rl-hero">
          <div class="rl-rw">
            ${w(e.score,i)}
            <div class="rl-rov">
              <span class="rl-snum">${e.score}</span>
              <span class="rl-ssub">/100</span>
            </div>
          </div>
          <div class="rl-hi">
            <div class="rl-grow">
              <span class="rl-gbadge" style="color:${r.color};background:${r.bg};border-color:${r.color}55">
                ${g(e.grade)} — ${r.label}
              </span>
            </div>
            <p class="rl-sum">${g(e.summary)}</p>
            ${l?`<div class="rl-chips">${l}</div>`:``}
          </div>
        </div>

        <div class="rl-arch">
          <span class="rl-aico">🏗</span>
          <div>
            <div class="rl-ameta">
              <span class="rl-albl">Arquitetura</span>
              <span class="rl-arat">${x[e.architecture.rating]??e.architecture.rating}</span>
            </div>
            <p class="rl-anotes">${g(e.architecture.notes)}</p>
          </div>
        </div>

        <div class="rl-g2">
          <section class="rl-sec">
            <h3 class="rl-ttl rl-ttl--green">✓ Pontos fortes</h3>
            <ul class="rl-ul">${o}</ul>
          </section>
          <section class="rl-sec">
            <h3 class="rl-ttl rl-ttl--amber">⚠ Pontos fracos</h3>
            <ul class="rl-ul">${s}</ul>
          </section>
        </div>

        <section class="rl-sec">
          <h3 class="rl-ttl rl-ttl--red">✕ Inconsistências</h3>
          <ul class="rl-ul">${c}</ul>
        </section>

        ${d}

        <section class="rl-sec">
          <h3 class="rl-ttl rl-ttl--blue">↑ Recomendações</h3>
          <ul class="rl-recs">${u}</ul>
        </section>

      </div>

      <footer class="rl-ft">
        Análise gerada por IA · Use como referência, não como verdade absoluta
      </footer>

    </div>
  `,t,`rl-overlay`)}function I(){let e=document.getElementById(m);return e||(e=document.createElement(`div`),e.id=m,document.body.appendChild(e)),e.shadowRoot??e.attachShadow({mode:`open`})}function L(e){let t=I();return t.innerHTML=`<style>${T()}</style>${e}`,t}function R(e){let t=e.getElementById(`rl-key-input`),n=e.getElementById(`rl-save-key`),r=e.getElementById(`rl-key-msg`);n?.addEventListener(`click`,async()=>{let e=t?.value.trim()??``;if(!e){r&&(r.textContent=`Insira a API key antes de salvar.`,r.className=`rl-keymsg rl-keymsg--err`);return}n.disabled=!0,r&&(r.textContent=``,r.className=`rl-keymsg`);let i=await chrome.runtime.sendMessage({type:`SAVE_API_KEY`,key:e});i?.ok?(r&&(r.textContent=`Salva! Clique em RepoLens novamente.`,r.className=`rl-keymsg rl-keymsg--ok`),setTimeout(K,1800)):(r&&(r.textContent=i?.error??`Erro ao salvar.`,r.className=`rl-keymsg rl-keymsg--err`),n.disabled=!1)}),chrome.storage.local.get([`userApiKey`,`geminiModel`],t=>{if(!t.userApiKey)return;let n=e.getElementById(`rl-model-section`);n&&(n.style.display=`block`);let r=t.geminiModel||`gemini-2.5-flash`,i=e.querySelector(`input[name="rl-gemini-model"][value="${r}"]`);i&&(i.checked=!0)}),e.querySelectorAll(`input[name="rl-gemini-model"]`).forEach(e=>{e.addEventListener(`change`,()=>{e.checked&&chrome.runtime.sendMessage({type:`SAVE_GEMINI_MODEL`,model:e.value})})}),chrome.storage.local.get([`deepMode`],t=>{let n=e.getElementById(`rl-deep-mode`);n&&(n.checked=!!t.deepMode)}),e.getElementById(`rl-deep-mode`)?.addEventListener(`change`,e=>{let t=e.target.checked;chrome.runtime.sendMessage({type:`SAVE_DEEP_MODE`,deepMode:t})})}function z(e){e.getElementById(`rl-key-btn`)?.addEventListener(`click`,B)}function B(){document.removeEventListener(`keydown`,q);let e=L(P(_()));e.getElementById(`rl-close`)?.addEventListener(`click`,K),e.getElementById(`rl-cancel`)?.addEventListener(`click`,K),document.addEventListener(`keydown`,q),R(e)}function V(e,t){let n=L(M(e,t,_()));n.getElementById(`rl-close`)?.addEventListener(`click`,K),z(n)}function H(e){W(),chrome.storage.local.get([`geminiModel`],n=>{let r=n.geminiModel||`gemini-2.5-flash`,i=t.find(e=>e.id===r)?.name??r,a=L(F(e,_(),i));a.getElementById(`rl-close`)?.addEventListener(`click`,K),a.getElementById(`rl-overlay`)?.addEventListener(`click`,e=>{e.target.id===`rl-overlay`&&K()}),document.addEventListener(`keydown`,q),z(a)})}function U(e,t=!1){let n=L(N(e,t,_()));n.getElementById(`rl-close`)?.addEventListener(`click`,K),n.getElementById(`rl-close-btn`)?.addEventListener(`click`,K),document.addEventListener(`keydown`,q),t?R(n):z(n)}function W(){document.body.style.overflow=`hidden`}function G(){document.body.style.overflow=``}function K(){document.getElementById(m)?.remove(),document.removeEventListener(`keydown`,q),G()}function q(e){e.key===`Escape`&&K()}async function J(){u((e,t)=>{p(!0),V(`Iniciando análise...`,0),chrome.runtime.sendMessage({type:`ANALYZE_REPO`,owner:e,repo:t}).catch(e=>{p(!1),U(`Falha ao contatar extensão: ${e.message}`)})});let t=location.pathname.match(/^\/([^/]+)\/([^/]+)/);if(t){let n=await e(`${t[1]}/${t[2]}`);n&&(d(()=>H(n)),f())}}chrome.runtime.onMessage.addListener(e=>{e.type===`ANALYSIS_PROGRESS`&&V(e.step,e.percent),e.type===`ANALYSIS_COMPLETE`&&(p(!1),H(e.result),d(()=>H(e.result)),f()),e.type===`ANALYSIS_ERROR`&&(p(!1),U(e.error,e.requiresApiKey))});var Y=location.href;new MutationObserver(()=>{location.href!==Y&&(Y=location.href,K(),setTimeout(J,500))}).observe(document.body,{subtree:!0,childList:!0}),J();