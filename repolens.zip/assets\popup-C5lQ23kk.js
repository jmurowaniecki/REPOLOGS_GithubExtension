import{a as e,n as t}from"./gemini-Dh4Er9PI.js";import{r as n}from"./api-key-manager-BLuFngi4.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function r(e,t,n){let r=document.createElement(`p`);r.className=n===`error`?`error-msg`:`success-msg`,r.textContent=t,e.replaceChildren(r)}async function i(){let[a,o]=await Promise.all([n(),e()]),s=o.geminiModel||`gemini-2.5-flash`,c=o.deepMode,l=t.map(e=>`
    <label class="model-item">
      <input type="radio" name="gemini-model" value="${e.id}" ${s===e.id?`checked`:``}/>
      <span class="model-name">${e.name}</span>
      <span class="tag ${e.free?`tag-free`:`tag-pro`}">${e.free?`Grátis`:`Pro`}</span>
    </label>
  `).join(``),u=document.getElementById(`app`);u.innerHTML=`
    <div class="header">
      <span class="logo" style="display: flex; gap: 5px;"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex-shrink:0"><path d="m13 13.5 2-2.5-2-2.5"/><path d="m21 21-4.3-4.3"/><path d="M9 8.5 7 11l2 2.5"/><circle cx="11" cy="11" r="8"/></svg> RepoLens</span>
      <span class="badge-free">Beta</span>
    </div>

    <div class="body">

      <div class="status-card">
        <div class="status-row">
          <span class="status-label">Consulta gratuita</span>
          <span class="status-value ${a.systemKeyUsed?`used`:`ok`}">
            ${a.systemKeyUsed?`Utilizada`:`Disponível`}
          </span>
        </div>
        <div class="status-row">
          <span class="status-label">API key própria</span>
          <span class="status-value ${a.hasUserKey?`ok`:``}">
            ${a.hasUserKey?`Configurada`:`Não configurada`}
          </span>
        </div>
        <div class="status-row">
          <span class="status-label">Total de análises</span>
          <span class="status-value">${a.analysisCount}</span>
        </div>
      </div>

      <div class="input-group">
        <p class="section-label">Sua API key do Gemini</p>
        <input
          type="password"
          id="api-key-input"
          placeholder="AIza..."
          value=""
          autocomplete="new-password"
        />
        <p class="input-hint">
          Obtenha grátis em
          <a href="https://aistudio.google.com" target="_blank">aistudio.google.com</a>
          → Get API key
        </p>
      </div>

      <button class="btn-primary" id="save-btn">Salvar API key</button>

      ${a.hasUserKey?`<button class="btn-danger" id="clear-btn">Remover API key</button>`:``}

      ${a.hasUserKey?`
        <div class="model-section">
          <p class="section-label">Modelo Gemini</p>
          <div class="model-list">${l}</div>
        </div>
      `:``}

      <div class="toggle-section">
        <div class="toggle-row">
          <div class="toggle-info">
            <span class="toggle-label">Análise profunda</span>
            <span class="toggle-desc">350 linhas por arquivo · Normal: 150 linhas</span>
          </div>
          <label class="toggle-switch" aria-label="Alternar análise profunda">
            <input type="checkbox" id="deep-mode-toggle" ${c?`checked`:``} />
            <span class="toggle-thumb"></span>
          </label>
        </div>
      </div>

      <div id="msg"></div>

    </div>

    <div class="footer">
      Repos públicos · Gratuito
    </div>
  `,document.getElementById(`save-btn`)?.addEventListener(`click`,async()=>{let e=document.getElementById(`api-key-input`).value.trim(),t=document.getElementById(`msg`);if(!e){r(t,`Insira uma API key válida`,`error`);return}try{let n=await chrome.runtime.sendMessage({type:`SAVE_API_KEY`,key:e});n?.ok?(r(t,`API key salva com sucesso!`,`success`),setTimeout(i,1500)):r(t,`Erro: ${n?.error??`desconhecido`}`,`error`)}catch(e){r(t,`Erro: ${e.message}`,`error`)}}),document.getElementById(`clear-btn`)?.addEventListener(`click`,async()=>{await chrome.runtime.sendMessage({type:`CLEAR_API_KEY`}),i()}),document.querySelectorAll(`input[name="gemini-model"]`).forEach(e=>{e.addEventListener(`change`,()=>{e.checked&&chrome.runtime.sendMessage({type:`SAVE_GEMINI_MODEL`,model:e.value})})}),document.getElementById(`deep-mode-toggle`)?.addEventListener(`change`,e=>{let t=e.target.checked;chrome.runtime.sendMessage({type:`SAVE_DEEP_MODE`,deepMode:t})})}i();