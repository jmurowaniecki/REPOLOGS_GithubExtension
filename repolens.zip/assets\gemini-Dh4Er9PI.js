var e={systemKeyUsed:!1,userApiKey:null,geminiModel:`gemini-2.5-flash`,deepMode:!1,analysisCount:0,cache:{},lastResults:{}};async function t(){let t=await chrome.storage.local.get(Object.keys(e));return{...e,...t}}async function n(e){await chrome.storage.local.set(e)}async function r(e,r){let i={...(await t()).cache,[e]:r},a=Object.keys(i);a.length>50&&delete i[a[0]],await n({cache:i})}async function i(e){return(await t()).lastResults[e]??null}async function a(e,r){await n({lastResults:{...(await t()).lastResults,[e]:r}})}function o(){return`Você é um especialista em qualidade de código e arquitetura de software.
Analise o repositório GitHub fornecido e retorne APENAS um JSON válido, sem texto adicional,
sem markdown, sem blocos de código. Apenas o JSON bruto.

O JSON deve seguir exatamente esta estrutura:
{
  "score": <número inteiro de 0 a 100>,
  "summary": "<resumo de 2-3 frases sobre o projeto>",
  "strengths": ["<ponto forte 1>", "<ponto forte 2>"],
  "weaknesses": ["<ponto fraco 1>", "<ponto fraco 2>"],
  "inconsistencies": ["<inconsistência 1>"],
  "architecture": {
    "rating": <"excellent" | "good" | "fair" | "poor">,
    "notes": "<observação sobre arquitetura>"
  },
  "recommendations": [
    { "priority": "high", "text": "<recomendação urgente>" },
    { "priority": "medium", "text": "<recomendação importante>" },
    { "priority": "low", "text": "<melhoria opcional>" }
  ],
  "techStack": ["<tecnologia 1>", "<tecnologia 2>"],
  "securityFlags": ["<flag de segurança se houver>"]
}

════════════════════════════════════════════
METODOLOGIA DE PONTUAÇÃO (score)
════════════════════════════════════════════

O score deve refletir a qualidade LÍQUIDA do projeto, equilibrando acertos e erros
pelo seu peso real — não apenas pela contagem. Siga este raciocínio:

1. PARTA DE UMA LINHA-BASE
   - Projeto trivial/vazio/boilerplate puro: base 30
   - Projeto pequeno com propósito claro: base 55
   - Projeto médio funcional: base 65
   - Projeto maduro e bem estruturado: base 75

2. CLASSIFIQUE CADA FRAQUEZA PELA SEVERIDADE e ajuste o score:
   - CRÍTICA  (segurança: secrets expostos, RCE, SQLi; perda de dados; funcionalidade
               central quebrada; ausência total de controle de erros em produção):
               desconte 15–20 pontos por ocorrência — UMA falha crítica já impede nota alta
   - GRAVE    (acoplamento forte entre camadas, ausência total de testes em projeto não-trivial,
               sem documentação relevante, dívida técnica pesada, performance gravemente
               prejudicada): desconte 8–12 pontos por ocorrência
   - MODERADA (duplicação relevante de código, tipos inconsistentes, tratamento de erros
               parcial, estrutura de pastas confusa): desconte 3–6 pontos por ocorrência
   - LEVE     (inconsistência de nomenclatura, comentários ausentes onde seriam úteis,
               pequenos desvios de estilo): desconte 1–2 pontos — muitos itens leves
               NÃO devem derrubar um projeto que tem base sólida

3. RECONHEÇA OS PONTOS FORTES e ajuste positivamente:
   - Testes robustos e bem organizados: +5 a +10
   - Arquitetura clara com separação de responsabilidades: +5 a +8
   - Documentação excelente (README, tipos, comentários estratégicos): +3 a +6
   - Segurança bem tratada (validações, sem secrets, dependências atualizadas): +3 a +5
   - Código idiomático, legível e consistente: +2 a +5

4. REGRAS DE CALIBRAÇÃO (obrigatórias):
   - Uma fraqueza CRÍTICA nunca permite score ≥ 75, independente dos pontos fortes
   - Uma fraqueza GRAVE raramente permite score ≥ 85
   - Um projeto sem fraquezas críticas ou graves, com vários pontos fortes reais, deve
     pontuar acima de 70
   - Muitos itens leves (5+ leves) sem nenhum grave não devem resultar em score < 55
   - Projeto vazio/boilerplate sem contribuição própria: máximo 40
   - Seja justo: não penalize pela ausência de features que o projeto nunca se propôs a ter

5. CORRESPONDÊNCIA SCORE → CONCEITO (para referência interna):
   85–100 → Excelente: código de alta qualidade, poucos problemas menores
   70–84  → Bom: sólido com melhorias claras mas não urgentes
   55–69  → Regular: funciona, mas com problemas notáveis que merecem atenção
   40–54  → Ruim: problemas graves que comprometem qualidade ou manutenibilidade
   0–39   → Crítico: falhas sérias, inseguro ou severamente incompleto

════════════════════════════════════════════
CRITÉRIOS DE AVALIAÇÃO
════════════════════════════════════════════
- Estrutura e organização (arquivos, pastas, separação de responsabilidades)
- Qualidade do código (legibilidade, nomenclatura, padrões, complexidade)
- Documentação (README, comentários estratégicos, tipos/contratos)
- Testes (presença, cobertura aparente, qualidade, confiabilidade)
- Segurança (secrets, dependências vulneráveis, práticas inseguras)
- Consistência (estilo, padrões, convenções ao longo do projeto)
- Arquitetura (camadas, acoplamento, coesão, escalabilidade)
- Manutenibilidade (duplicação, dívida técnica, complexidade ciclomática)`}function s(e,t,n){let r=n.map(({path:e,content:t})=>`=== ARQUIVO: ${e} ===\n${t}\n=== FIM: ${e} ===`).join(`

`);return`Repositório: ${e}/${t}
URL: https://github.com/${e}/${t}
Arquivos analisados: ${n.length}

${r}

Analise este repositório e retorne o JSON conforme instruído.`}var c=`https://generativelanguage.googleapis.com/v1beta/models`,l=`gemini-2.5-flash`,u=[{id:`gemini-2.5-flash`,name:`Gemini 2.5 Flash`,free:!0},{id:`gemini-2.5-flash-lite`,name:`Gemini 2.5 Flash Lite`,free:!0},{id:`gemini-2.5-pro`,name:`Gemini 2.5 Pro`,free:!1}],d=62e3,f=1;function p(e){return e>=85?`A`:e>=70?`B`:e>=55?`C`:e>=40?`D`:`F`}function m(e){let t=e.replace(/^```json\s*/i,``).replace(/^```\s*/i,``).replace(/```\s*$/i,``).trim();try{let e=JSON.parse(t);if(typeof e.score!=`number`)throw Error(`JSON sem campo score`);let n=Math.max(0,Math.min(100,Math.round(e.score)));return e.score=n,e.grade=p(n),e}catch(e){throw Error(`Falha ao parsear resposta do Gemini: ${e.message}`)}}async function h(e,t,n,r,i=l,a){let u=o(),p=s(t,n,r),h={system_instruction:{parts:[{text:u}]},contents:[{role:`user`,parts:[{text:p}]}],generationConfig:{temperature:.2,maxOutputTokens:8192,responseMimeType:`application/json`}},g=JSON.stringify(h),_=Math.ceil(g.length/3);console.log(`[Gemini] Modelo: ${i} | Tokens estimados: ~${_.toLocaleString()} | ${t}/${n} | ${r.length} arquivo(s)`);async function v(t){let n;if(e.mode===`api-key`)n=await fetch(`${c}/${i}:generateContent`,{method:`POST`,headers:{"Content-Type":`application/json`,"X-Goog-Api-Key":e.apiKey},body:g});else{let t={"Content-Type":`application/json`};e.token&&(t[`X-Request-Token`]=e.token),n=await fetch(`${e.url}/api/analyze`,{method:`POST`,headers:t,body:JSON.stringify({model:i,body:h})})}let r;try{r=await n.json()}catch{throw Error(`Gemini HTTP ${n.status}: resposta não é JSON válido`)}if(r.error){console.error(`[Gemini] Erro da API:`,JSON.stringify(r.error));let{code:e,message:n}=r.error;if(e===429){if(n.includes(`limit: 0`))throw Error(`Modelo inválido para API key selecionada ou Quota zero no projeto. Crie a key em aistudio.google.com/app/apikey (não no Google Cloud Console).`);if(t>0){let e=Math.ceil(d/1e3);return console.warn(`[Gemini] Rate limit 429 — aguardando ${e}s antes de tentar novamente`),a?.(e),await new Promise(e=>setTimeout(e,d)),v(t-1)}throw Error(`Rate limit do Gemini atingido. Aguarde alguns minutos e tente novamente.`)}let i=n.toLowerCase().includes(`api key`)||n.toLowerCase().includes(`api_key`)||r.error.status===`INVALID_ARGUMENT`;throw e===400&&i?n.toLowerCase().includes(`expired`)?Error(`API key expirada ou ainda propagando. Aguarde 1-2 minutos após criar a key e tente novamente.`):Error(`API key inválida. Verifique nas configurações da extensão.`):Error(`Gemini API [${e}]: ${n}`)}if(!n.ok)throw Error(`Gemini HTTP ${n.status}: ${n.statusText}`);if(!r.candidates?.[0]?.content?.parts?.[0]?.text)throw Error(`Resposta vazia do Gemini`);let o=r.candidates[0].content.parts[0].text;return m(o)}return v(f)}export{t as a,n as c,i,u as n,r as o,h as r,a as s,l as t};